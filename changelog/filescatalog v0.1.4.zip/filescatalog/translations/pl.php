<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{filescatalog}prestashop>filescatalog_e7500cb01a408f42edad1d2652cca1da'] = 'Katalog plików';
$_MODULE['<{filescatalog}prestashop>filescatalog_84b3eb4c3b3f9feae39c16093bd8a141'] = 'Niestandardowy moduł umożliwiający pokazanie katalogu plików na stronie poprzez zastąpienie wskazanego ID strony.';
$_MODULE['<{filescatalog}prestashop>filescatalog_c888438d14855d7d96a2724ee9c306bd'] = 'Zaktualizowano ustawienia';
$_MODULE['<{filescatalog}prestashop>filescatalog_c48484622a8a357ec6971245b203ad22'] = 'Katalog został zaktualizowany';
$_MODULE['<{filescatalog}prestashop>filescatalog_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{filescatalog}prestashop>filescatalog_9fe8373c5e74782be077d5fffaf26ac9'] = 'Ścieżka do analizy: public_html/';
$_MODULE['<{filescatalog}prestashop>filescatalog_51cab66f64d78de259de769662661e7f'] = 'ID strony do zastąpienia:';
$_MODULE['<{filescatalog}prestashop>filescatalog_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{filescatalog}prestashop>filescatalog_63a6a88c066880c5ac42394a22803ca6'] = 'Odśwież';
